# Upstream Template Info

This package contains a modified `Zotero.dotm` derived from Zotero's official Mac Word template.

- Upstream repository: https://github.com/zotero/zotero-word-for-mac-integration.git
- Upstream commit: `084f16d78b4924b15ad24c83dd5d8aaaeb9998d8`
- Upstream template path: `install/Zotero.dotm`
- Upstream license: AGPLv3 (see `UPSTREAM_COPYING.txt`)

The hyperlink helper additions in this project are integrated into the upstream template so that Word for Mac users can manually install the template.
