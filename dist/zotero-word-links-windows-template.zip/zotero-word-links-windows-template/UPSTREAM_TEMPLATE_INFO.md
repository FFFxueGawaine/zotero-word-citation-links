# Upstream Template Info

This package contains a modified `Zotero.dotm` derived from Zotero's official Windows Word template.

- Upstream repository: https://github.com/zotero/zotero-word-for-windows-integration.git
- Upstream commit: `d76680608ebd6b649459c5939d3979393f41455a`
- Upstream template path: `install/Zotero.dotm`
- Upstream license: AGPLv3 (see `UPSTREAM_COPYING.txt`)

The hyperlink helper additions in this project are integrated into the upstream template so that Windows users can install by directly replacing `Zotero.dotm`.
